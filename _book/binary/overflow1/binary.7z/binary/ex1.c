#include <stdio.h>
#include <string.h>
int main()
{
	int a = 1;
	int b = 2;
	int c = 3;
	printf("%d\n", a);
	printf("%d\n", b);
	printf("%d\n", c);
}