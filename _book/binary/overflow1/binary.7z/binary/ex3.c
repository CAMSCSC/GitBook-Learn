#include <stdio.h>
#include <string.h>

int func(int x)
{
	printf("%d\n", x);
}

int main()
{
	printf("Start\n");
	func(15);
	printf("End\n");
}